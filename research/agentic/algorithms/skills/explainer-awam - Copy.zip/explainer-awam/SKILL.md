---
name: explainer-awam
description: Membuat halaman report visual (HTML) yang mengajarkan topik teknologi atau keuangan kepada orang awam, dengan template tetap - struktur Apa/Bagaimana/Mengapa penting di setiap bab, kotak istilah, diagram model bisnis, demo interaktif, dan kamus istilah. Gunakan skill ini SETIAP KALI user minta menjelaskan whitepaper, dokumen, PDF, link, produk, startup, kripto, blockchain, AI, fintech, investasi, saham, regulasi, atau laporan perusahaan untuk pembaca non-teknis - misalnya "jelaskan", "jelasin untuk orang awam", "sederhanakan", "bedah whitepaper ini", "apa itu X dan bagaimana cara kerjanya", "model bisnisnya seperti apa", atau "explain this to a beginner" - bahkan jika user tidak menyebut kata report, template, atau HTML.
---

# Explainer untuk orang awam

Skill ini menghasilkan satu halaman HTML yang mengajarkan sebuah topik teknologi atau keuangan kepada orang yang tidak punya latar belakang di bidang itu. Pembaca harus selesai dengan pemahaman yang dalam tentang **apa**, **bagaimana**, dan **mengapa** - bukan sekadar ringkasan.

Template ini sudah disetujui user. Pakai setiap kali skill terpicu, tanpa menanyakan format dulu. Pengecualian: user eksplisit minta jawaban singkat di chat, atau minta format lain (Word, PDF, slide).

## File di skill ini

- `assets/template.html` - kerangka halaman: CSS lengkap (mode gelap, ramah HP, safe-area), semua komponen, dan placeholder `{{...}}`. Selalu mulai dari sini.
- `references/diagram-recipes.md` - resep diagram SVG. Baca sebelum menggambar diagram pertama.
- `references/contoh-bitcoin.html` - contoh jadi (Bitcoin whitepaper) yang menjadi standar kualitas. Lihat untuk nada bahasa, kepadatan diagram, dan demo interaktif. Jangan salin isinya ke topik lain.

## Workflow

1. **Baca sumber sampai habis.** URL atau PDF: ambil dengan web_fetch. File upload: baca dari disk. Semua angka, nama, dan klaim harus berasal dari sumber, bukan dari ingatan. Topik tanpa dokumen (mis. "jelaskan reksa dana"): cari sumber yang kredibel dulu.
2. **Petakan bab.** Dokumen bab (whitepaper, laporan): ikuti urutan bab aslinya, dan tulis label sumber di setiap bab ("Whitepaper bab 4, Proof-of-Work"). Topik tanpa dokumen: urutkan masalah → solusi → cara kerja → model bisnis → risiko → kesimpulan.
3. **Pilih satu contoh berjalan.** Tokoh lokal (Budi, Sari, Andi) dan angka konkret, dipakai konsisten dari bab awal sampai akhir. Pembaca lebih mudah mengikuti satu cerita daripada contoh yang berganti-ganti.
4. **Temukan konsep tersulit.** Biasanya mekanisme inti (di Bitcoin: Proof of Work). Di situlah user paling mungkin tersesat, jadi beri demo interaktif, pecah jadi langkah-langkah kecil, dan mulai dengan "masalah yang tersisa" dari bab sebelumnya.
5. **Tulis isi** mengikuti aturan bahasa di bawah.
6. **Bangun HTML** dari `assets/template.html`. Ganti semua `{{...}}`, hapus komentar petunjuk yang tidak dipakai. Gambar diagram mengikuti `references/diagram-recipes.md`.
7. **Cek checklist** di akhir file ini.
8. **Publikasikan.** Di claude.ai: simpan di `/mnt/user-data/outputs/` lalu Artifact tool action `publish` dengan favicon emoji yang relevan. Revisi: edit file yang sama lalu publish ulang dengan `url` artifact sebelumnya. Tanpa Artifact tool: `present_files`.
9. **Pesan chat penutup** 2-4 kalimat: apa yang ada di halaman (jumlah bab, diagram, demo). Jangan mengulang isi halaman di chat.

## Aturan bahasa

Aturan ini berasal dari koreksi langsung user, jadi prioritasnya paling tinggi.

**Istilah umum tidak diterjemahkan.** Pakai hash, block, blockchain, node, wallet, fee, mining, miner, nonce, public key, private key, exchange, startup, revenue, AI, model, dan sejenisnya apa adanya, karena itulah kata yang dipakai orang sehari-hari dan yang akan mereka temui di luar. Jangan membuat padanan buatan lalu memakainya sebagai pengganti istilah.

- Salah: "Hash adalah sidik jari digital…" lalu sepanjang halaman menulis "sidik jari halaman ini".
- Benar: "Hash adalah kode unik dengan panjang tetap yang dihasilkan dari sebuah data." Analogi boleh dipakai sekali untuk menjelaskan, tapi istilahnya tetap "hash".

**Kata sehari-hari tetap sehari-hari.** Jangan membakukan atau mengindonesiakan berlebihan. Tulis seperti orang menjelaskan ke teman.

**Tidak bertele-tele.** Kalimat pendek, satu ide per paragraf, tanpa pembuka basa-basi. Kalau satu kalimat cukup, jangan pakai tiga.

**Bangun bertahap.** Jangan memakai konsep sebelum dijelaskan. Setiap bab menyambung ke bab sebelumnya dengan alur sebab-akibat: "Hash membuat kecurangan ketahuan, tapi masih ada celah…" → bab berikutnya menutup celah itu. Lompatan konsep adalah penyebab utama pembaca bingung.

**Analogi lokal, satu per konsep.** Uang tunai dan gorengan, arisan RT, BPKB kendaraan, warung dan uang kembalian, pengumuman lewat pengeras suara masjid, bagan turnamen sepak bola, papan bursa saham. Jangan menumpuk beberapa analogi untuk satu hal.

**Angka konkret** lebih mudah dipahami daripada penjelasan abstrak ("Budi bayar 0,5 BTC, Sari dapat 0,3 BTC").

Sapa pembaca dengan "Anda". Bahasa halaman mengikuti bahasa user (default Indonesia).

## Struktur halaman

1. **Hero:** judul pola "[Topik], dijelaskan dari nol"; lead 2-3 kalimat (siapa, kapan, apa); kotak "apa itu [jenis dokumen]" dengan link sumber; kotak "cara membaca"; daftar isi bernomor.
2. **Bab-bab.** Setiap bab punya nomor, judul `h2`, label sumber, lalu tiga bagian `h3`:
   - **Apa** - pengertian
   - **Bagaimana** - cara kerja, dengan diagram atau demo
   - **Mengapa penting** - masalah yang terselesaikan dan sambungannya ke bab berikutnya

   Judul `h3` boleh divariasikan ("Masalah yang tersisa", "Bagaimana: coba sendiri"), asalkan ketiga pertanyaan terjawab.
   Setiap istilah teknis mendapat kotak `.term` saat **pertama kali** muncul.
3. **Bab model bisnis - wajib.** Diagram aliran vertikal (siapa memberi apa, siapa mendapat apa), tabel `Pihak | Memberi | Mendapat`, sumber pendapatan dan biaya, dan alasan setiap pihak mau ikut. Topik tanpa perusahaan (protokol, konsep): jelaskan sebagai ekosistem - siapa terlibat dan apa insentifnya.
4. **Risiko atau batasan**, jika sumber membahasnya atau topiknya menyangkut uang.
5. **Kesimpulan:** daftar bernomor 4-6 poin yang menceritakan ulang alur dari masalah ke solusi.
6. **Catatan "bukan saran keuangan"** untuk topik keuangan, investasi, atau kripto.
7. **Kamus istilah** (`dl.gloss`): semua istilah yang muncul, urut sesuai kemunculan.
8. **Footer** dengan link sumber.

## Visual

- **Diagram:** minimal satu per bab yang membahas mekanisme. Dokumen lengkap biasanya butuh 8-12 diagram.
- **Demo interaktif:** minimal satu, untuk konsep tersulit. Polanya: pembaca mengubah sesuatu → hasilnya langsung berubah. Contoh: hash playground, simulasi mining, kalkulator bunga majemuk, slider risiko vs imbal hasil, simulasi pembagian fee.
- **Angka dari sumber:** komponen `.bars` atau tabel.
- **Warna bermakna:** aksen = hal yang disorot, teal = sah/hasil/untung, merah = masalah/risiko/penipu, netral = sisanya. Ganti `--accent` di template jika topik punya warna identitas (Bitcoin oranye, misalnya). Selain itu jangan mengubah sistem desain.

## Aturan teknis

- Satu file HTML self-contained. Font hanya dari Google Fonts (sudah di template). Script inline; library eksternal hanya dari cdnjs.cloudflare.com atau cdn.jsdelivr.net. Tidak ada gambar dari internet.
- `crypto.subtle` tersedia untuk demo hash. Jika memakai localStorage, bungkus dengan try/catch.
- Hak cipta: parafrase sumber dengan kata-kata sendiri. Kutipan langsung jarang, di bawah 15 kata.

## Checklist sebelum publish

- [ ] Tidak ada istilah umum yang diterjemahkan paksa, dan tidak ada padanan buatan yang menggantikan istilah
- [ ] Setiap bab menjawab apa, bagaimana, dan mengapa penting
- [ ] Setiap istilah teknis punya kotak `.term` saat pertama muncul dan ada di kamus
- [ ] Tidak ada konsep yang dipakai sebelum dijelaskan
- [ ] Ada diagram model bisnis dan tabel pihak
- [ ] Ada minimal satu demo interaktif, dan sudah dicek berjalan
- [ ] Semua angka sesuai sumber
- [ ] Tidak ada teks SVG yang keluar dari kotaknya (hitung lebar sesuai `diagram-recipes.md`)
- [ ] Tidak ada `{{...}}` yang tertinggal
- [ ] Aman di layar HP dan mode gelap
- [ ] Pesan penutup di chat singkat dan tidak mengulang isi
